// ************************************************************************************
//
//  BBQcsvxParser.m
//  BBQKing
//
// ************************************************************************************

// Header file
#import "BBQCSVParser.h"
#import "MTGViewController.h"

// ************************************************************************************

@implementation BBQCSVParser

@synthesize parsedcsvxArray = _parsedcsvxArray;


// ************************************************************************************


#pragma mark -
#pragma mark csv parsing methods


// --------------------------------------------
// * Create an array from a csv NSData object *
// --------------------------------------------

- (NSMutableArray *)arrayFromcsvxData:(NSData *)_csvXData headerRow:(Boolean)_headerRow {
    
    // Convert the NSData into an NSString
    NSString *csvxString = [[NSString alloc] initWithData:_csvXData encoding:NSUTF8StringEncoding];
        
    // Split each record (line) in the csvxDataString into an individual array element (split on the newline character \n)
    NSMutableArray *csvxArray = [[csvxString componentsSeparatedByString:@"\n"] mutableCopy];
        
    // Create an array to hold the parsed csvx data
    NSMutableArray *parsedcsvxArray = [[NSMutableArray alloc] init];
        
    // If there is a heading row then start the loop counter at 1 (to skip the heading row)    
    for (int i = (_headerRow ? 1 : 0); i < [csvxArray count]; i++) {
        
        // Get a reference to this record (line) as a string, and remove any extranous new lines or alike
        NSString *csvxRecordString = [[csvxArray objectAtIndex:i] stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                
        // Split the line by the comma delimeter
        NSMutableArray *csvxRecordArray = [[csvxRecordString componentsSeparatedByString:@","] mutableCopy];
                
        // Check that there are actually fields (i.e. this is not a blank line)
        if ( ([csvxRecordArray count] > 0) && ([[csvxRecordArray objectAtIndex:0] length] > 0) ) {
            
            // Add the record array to the parsed csvx array
            [parsedcsvxArray addObject:csvxRecordArray];
            
        }
        
    }
    
    
        
    // Return the parsed array
    return parsedcsvxArray;
    
}

- (NSMutableArray *)arrayFromcsvyData:(NSData *)_csvYData headerRow:(Boolean)_headerRow {
    
    // Convert the NSData into an NSString
    NSString *csvyString = [[NSString alloc] initWithData:_csvYData encoding:NSUTF8StringEncoding];
    
    // Split each record (line) in the csvxDataString into an individual array element (split on the newline character \n)
    NSMutableArray *csvyArray = [[csvyString componentsSeparatedByString:@"\n"] mutableCopy];
    
    // Create an array to hold the parsed csvx data
    NSMutableArray *parsedcsvyArray = [[NSMutableArray alloc] init];
    
    // If there is a heading row then start the loop counter at 1 (to skip the heading row)
    for (int i = (_headerRow ? 1 : 0); i < [csvyArray count]; i++) {
        
        // Get a reference to this record (line) as a string, and remove any extranous new lines or alike
        NSString *csvyRecordString = [[csvyArray objectAtIndex:i] stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        
        // Split the line by the comma delimeter
        NSMutableArray *csvyRecordArray = [[csvyRecordString componentsSeparatedByString:@"\n"] mutableCopy];
        
        // Check that there are actually fields (i.e. this is not a blank line)
        if ( ([csvyRecordArray count] > 0) && ([[csvyRecordArray objectAtIndex:0] length] > 0) ) {
            
            // Add the record array to the parsed csvy array
            [parsedcsvyArray addObject:csvyRecordArray];
            
        }
        
    }
    
    // Return the parsed array
    return parsedcsvyArray;
    
}

@end