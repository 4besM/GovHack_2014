//
//  MTGAppDelegate.h
//  MapTesting
//
//  Created by Mark Glanville on 11/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>

@interface MTGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
