//
//  MTGTableViewController.h
//  MapTesting
//
//  Created by Mark Glanville on 12/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTGDetailViewController.h"

@interface MTGTableViewControllerTwo : UIViewController <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate, UISearchDisplayDelegate>

@property (retain) NSMutableArray *parsedcsvxArray;
@property (retain) IBOutlet UITableView *tableView;

@property (copy, nonatomic) NSMutableArray *artArray;
@property (copy, nonatomic) NSMutableArray *descArray;
@property (copy, nonatomic) NSMutableArray *artistArray;
@property int i;

@end
