//
//  MTGViewController.h
//  MapTesting
//
//  Created by Mark Glanville on 11/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>


@interface MTGViewController : UIViewController {
    NSMutableArray* parsedcsvxArray;

}
//@property (strong, nonatomic) IBOutlet GMSMapView *mapView;
//@property (weak, nonatomic) IBOutlet UIView *subview;
@property (weak, nonatomic) UIImage *icon;
@property (retain) NSMutableArray* parsedcsvxArray;

@end
