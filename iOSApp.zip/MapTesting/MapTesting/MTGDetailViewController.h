//
//  MTGDetailViewController.h
//  MapTesting
//
//  Created by Mark Glanville on 13/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTGTableViewControllerTwo.h"

@interface MTGDetailViewController : UIViewController

@property (weak, nonatomic) UIImage *imageOne;
@property (weak, nonatomic) NSString *labelOne;
@property (weak, nonatomic) NSString *labelTwo;
@property (weak, nonatomic) NSString *labelThree;
@property (weak, nonatomic) IBOutlet UILabel *labelOneOutlet;
@property (weak, nonatomic) IBOutlet UILabel *labelTwoOutlet;
@property (weak, nonatomic) IBOutlet UILabel *labelThreeOutlet;
//@property (weak, nonatomic) IBOutlet UIImageView *imageOneOutlet;
@property (copy, nonatomic) NSMutableArray *artArray;
@property (copy, nonatomic) NSMutableArray *descArray;
@property (copy, nonatomic) NSMutableArray *artistArray;
@property (nonatomic) NSInteger *indexPathNumber;

- (void) setText:(NSString *)text;
//- (void) setImage:(UIImage *)image;

@end
