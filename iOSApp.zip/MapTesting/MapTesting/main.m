//
//  main.m
//  MapTesting
//
//  Created by Mark Glanville on 11/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MTGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MTGAppDelegate class]));
    }
}
