//
//  MTGTableViewController.m
//  MapTesting
//
//  Created by Mark Glanville on 12/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import "MTGTableViewControllerTwo.h"
#import "BBQCSVParser.h"
#import "MTGDetailViewController.h"

@interface MTGTableViewControllerTwo ()

@end

@implementation MTGTableViewControllerTwo

@synthesize parsedcsvxArray = _parsedcsvxArray;
//@synthesize indexPathNumber = _indexPathNumber;



- (void) viewDidLoad {
    [super viewDidLoad];
    
    //[self.tableView setFrame:CGRectMake(0, 0, 100, 150)];
    
    //NSLog(@"%@", self.artArray);
    
    NSString *titlestrBundle = [[NSBundle mainBundle] pathForResource:@"titles" ofType:@"csv"];
    NSString *titlecsvString = [NSString stringWithContentsOfFile:titlestrBundle encoding:NSUTF8StringEncoding error:nil];
    //NSLog(@"%@", titlecsvString);
    NSData *titlecsvData = [[NSData alloc] init];
    titlecsvData = [titlecsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *titlecsvParser = [[BBQCSVParser alloc] init];
    self.artArray = [titlecsvParser arrayFromcsvxData:titlecsvData headerRow:NO];
    
    NSString *descstrBundle = [[NSBundle mainBundle] pathForResource:@"descriptions" ofType:@"csv"];
    NSString *desccsvString = [NSString stringWithContentsOfFile:descstrBundle encoding:NSUTF8StringEncoding error:nil];
    //NSLog(@"%@", titlecsvString);
    NSData *desccsvData = [[NSData alloc] init];
    desccsvData = [desccsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *desccsvParser = [[BBQCSVParser alloc] init];
    self.descArray = [desccsvParser arrayFromcsvyData:desccsvData headerRow:NO];
    
    NSString *artiststrBundle = [[NSBundle mainBundle] pathForResource:@"artists" ofType:@"csv"];
    NSString *artistcsvString = [NSString stringWithContentsOfFile:artiststrBundle encoding:NSUTF8StringEncoding error:nil];
    //NSLog(@"%@", titlecsvString);
    NSData *artistcsvData = [[NSData alloc] init];
    artistcsvData = [artistcsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *artistcsvParser = [[BBQCSVParser alloc] init];
    self.artistArray = [artistcsvParser arrayFromcsvyData:artistcsvData headerRow:NO];
    //NSLog(@"%@", self.artArray);
    
    /*for (NSString *title in titlecsvArray) {
        [self.artArray addObject:title];
    }*/
    //[self.artArray addObject:@"asd"];
    //NSLog(@"si: %@", [self.artArray objectAtIndex:0]);
    self.i = 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //NSLog(@"%i", self.artArray.count);
    //return 10;
    return [self.artArray count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *titleTableIdentifier = @"TitleTableCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:titleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:titleTableIdentifier];
    }
    
    /*for (int i = 0; i < [self.artArray count]; i++) {
        NSLog(@"%i: %ld", i, (long)indexPath.row);
    }*/
    
    //cell.textLabel.text = [self.artArray objectAtIndex:indexPath.row];
    //cell.textLabel.text = @"asdfghjkl";
    //NSLog(@"%@", cell);
    //NSLog(@"indexPath: %@", indexPath);
    //NSLog(@"i: %i", self.i);
    //NSString *debugString = @"Debug";
    NSString *titleString =[[self.artArray objectAtIndex:indexPath.row] objectAtIndex:0];
    //NSLog(@"Section: %ld", (long)indexPath.section);
    //NSLog(@"Row: %ld", (long)indexPath.row);
    //NSLog(@"String: %@", titleString);
    //cell.textLabel.text = [self.artArray objectAtIndex:self.i];
    cell.textLabel.text = titleString;

    return cell;
    
    self.i++;
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(NSIndexPath *)indexPath {
    
    MTGDetailViewController *detailViewController = segue.destinationViewController;
    detailViewController.indexPathNumber = (int *)indexPath.row;
    detailViewController.artArray = self.artArray;
    detailViewController.descArray = self.descArray;
    detailViewController.artistArray = self.artistArray;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MTGDetailViewController *detailViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MTGDetailViewController"];
    
    
    //NSString *titleName = [[self.artArray objectAtIndex:indexPath.row] objectAtIndex:0];
    //NSLog(@"%@", titleName);
    
    //NSInteger indexPathNumber = indexPath.row;
    //NSLog(@"%ld", (long)indexPathNumber);
    
    [detailViewController setText:[[self.artArray objectAtIndex:indexPath.row] objectAtIndex:0]];
    //NSLog(@"%@", [[self.artArray objectAtIndex:indexPath.row] objectAtIndex:0]);
    
    //NSLog(@"arblarble");
    
    //NSLog(@"arblarble2");
    
    [self performSegueWithIdentifier:@"DetailPush" sender:indexPath];
    
    //[self.navigationController pushViewController:detailViewController animated:NO];
}

@end
