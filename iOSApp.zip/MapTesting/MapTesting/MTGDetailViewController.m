//
//  MTGDetailViewController.m
//  MapTesting
//
//  Created by Mark Glanville on 13/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import "MTGDetailViewController.h"

@interface MTGDetailViewController ()

@end

@implementation MTGDetailViewController

@synthesize labelOneOutlet = _labelOneOutlet;
@synthesize indexPathNumber = _indexPathNumber;
@synthesize artArray = _artArray;
@synthesize descArray = _descArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    
    NSLog(@"asd");
    // Do any additional setup after loading the view.
    NSLog(@"%zd", self.indexPathNumber);
    int indexPathInteger = (int)self.indexPathNumber;
    NSLog(@"%i", indexPathInteger);
    NSString *detailTitleString = [[self.artArray objectAtIndex:indexPathInteger] objectAtIndex:0];
    NSLog(@"%@", [self.artArray objectAtIndex:indexPathInteger]);
    NSLog(@"%@", detailTitleString);
    [self.labelOneOutlet setText:detailTitleString];
    //self.labelOne = @"123";
  
    NSString *detailDescString = [[self.descArray objectAtIndex:indexPathInteger] objectAtIndex:0];
    [self.labelTwoOutlet setText:detailDescString];
    [self.labelTwoOutlet sizeToFit];
    
    NSString *detailArtistString = [[self.artistArray objectAtIndex:indexPathInteger] objectAtIndex:0];
    [self.labelThreeOutlet setText:detailArtistString];
    [self.labelThreeOutlet sizeToFit];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setText:(NSString *)text {
    self.labelOne = text;
}



/*- (void)setImage:(UIImage *)image {
    self.imageOne = image;
}*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
