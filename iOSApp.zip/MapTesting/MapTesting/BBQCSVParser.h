// ************************************************************************************
//
//  BBQCSVParser.h
//  BBQKing
//
// ************************************************************************************

@interface BBQCSVParser : NSObject {
    NSMutableArray* parsedcsvxArray;
    
}

// ************************************************************************************

// Create an array from a CSV NSData object
- (NSMutableArray *)arrayFromcsvxData:(NSData *)_csvXData headerRow:(Boolean)_headerRow;
- (NSMutableArray *)arrayFromcsvyData:(NSData *)_csvYData headerRow:(Boolean)_headerRow;


@property (retain) NSMutableArray* parsedcsvxArray;
// ************************************************************************************

@end