//
//  MTGViewController.m
//  MapTesting
//
//  Created by Mark Glanville on 11/07/2014.
//  Copyright (c) 2014 Mark Glanville. All rights reserved.
//

#import "MTGViewController.h"
#import <GoogleMaps/GoogleMaps.h>
#import "BBQCSVParser.h"

@implementation MTGViewController {
    //GMSMapView *mapView_;
}

@synthesize parsedcsvxArray = _parsedcsvxArray;

- (void)viewDidLoad {
    
    // Insert code here
    
    NSString *xstrBundle = [[NSBundle mainBundle] pathForResource:@"csvXData" ofType:@"csv"];
    NSString *xcsvString = [NSString stringWithContentsOfFile:xstrBundle encoding:NSUTF8StringEncoding error:nil];
    //NSLog(@"%@", xcsvString);
    NSData *xcsvData = [[NSData alloc] init];
    xcsvData = [xcsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *xcsvParser = [[BBQCSVParser alloc] init];
    NSMutableArray *xcsvArray = [xcsvParser arrayFromcsvxData:xcsvData headerRow:NO];
    //NSLog(@"%@", xcsvArray);
    
    
    NSString *ystrBundle = [[NSBundle mainBundle] pathForResource:@"csvYData" ofType:@"csv"];
    NSString *ycsvString = [NSString stringWithContentsOfFile:ystrBundle encoding:NSUTF8StringEncoding error:nil];
    //NSLog(@"%@", ycsvString);
    NSData *ycsvData = [[NSData alloc] init];
    ycsvData = [ycsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *ycsvParser = [[BBQCSVParser alloc] init];
    NSMutableArray *ycsvArray = [ycsvParser arrayFromcsvxData:ycsvData headerRow:NO];
    //NSLog(@"%@", ycsvArray);
    
    NSString *titlestrBundle = [[NSBundle mainBundle] pathForResource:@"titles" ofType:@"csv"];
    NSString *titlecsvString = [NSString stringWithContentsOfFile:titlestrBundle encoding:NSUTF8StringEncoding error:nil];
    //NSLog(@"%@", titlecsvString);
    NSData *titlecsvData = [[NSData alloc] init];
    titlecsvData = [titlecsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *titlecsvParser = [[BBQCSVParser alloc] init];
    NSMutableArray *titlecsvArray = [titlecsvParser arrayFromcsvxData:titlecsvData headerRow:NO];
    
    NSString *artiststrBundle = [[NSBundle mainBundle] pathForResource:@"artists" ofType:@"csv"];
    NSString *artistcsvString = [NSString stringWithContentsOfFile:artiststrBundle encoding:NSUTF8StringEncoding error:nil];
    NSData *artistcsvData = [[NSData alloc] init];
    artistcsvData = [artistcsvString dataUsingEncoding:NSUTF8StringEncoding];
    
    BBQCSVParser *artistcsvParser = [[BBQCSVParser alloc] init];
    NSMutableArray *artistcsvArray = [artistcsvParser arrayFromcsvxData:artistcsvData headerRow:NO];
    
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:-35.27903
                                                            longitude:149.123661
                                                                 zoom:9];
    GMSMapView *map2 = [GMSMapView mapWithFrame:CGRectMake(0, 0, 320, 436) camera:camera];
    [self.view addSubview:map2];
    map2.myLocationEnabled = YES;
    map2.settings.myLocationButton = YES;
    map2.settings.compassButton = YES;
    
    NSMutableSet *markerSet = [[NSMutableSet alloc] init];
    for (int i = 0; i <=125; i++) {
        NSNumber *xDataNumber = [[xcsvArray objectAtIndex:i] objectAtIndex:0];
        CLLocationDegrees xData = [xDataNumber doubleValue];
        NSNumber *yDataNumber = [[ycsvArray objectAtIndex:i] objectAtIndex:0];
        CLLocationDegrees yData = [yDataNumber doubleValue];
        NSString *titleData = [[titlecsvArray objectAtIndex:i] objectAtIndex:0];
        NSString *artistData = [[artistcsvArray objectAtIndex:i] objectAtIndex:0];
        

        CLLocationCoordinate2D position = CLLocationCoordinate2DMake(xData, yData);
        GMSMarker *marker = [GMSMarker markerWithPosition:position];
        marker.title = titleData;
        marker.snippet = artistData;
        marker.map = nil;
        
        [markerSet addObject:marker];
    }
    
    for (GMSMarker *markers in markerSet) {
        markers.map = map2;
    }
    
}

@end